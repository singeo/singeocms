<?php
/**
 * 系统配置控制类
 * User: singeo
 * Date: 2018/4/27 0027
 * Time: 上午 11:21
 */

namespace app\admin\controller;


class Consoleconfig extends Base
{
    public function index(){
        echo '系统设置' ;
    }
}