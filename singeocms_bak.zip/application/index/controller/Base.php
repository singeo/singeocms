<?php
/**
 * Created by PhpStorm.
 * User: singeo
 * Date: 2018/11/12 0012
 * Time: 下午 2:26
 */

namespace app\index\controller;


use think\Cache;
use think\Controller;
use think\Request;

class Base extends Controller
{
    /**
     * 栏目ID
     * @var
     */
    public $column_id = 0;

    /**
     * 当前栏目信息
     * @var array
     */
    public $cur_column_info = [] ;

    /**
     * 网站配置信息
     * @var array
     */
    public $web_config = [] ;


    /**
     * Base constructor.
     * @param Request|null $request
     */
    public function __construct(Request $request = null)
    {
        parent::__construct($request);
        //读取网站配置
        $this->web_config = Cache::get(config('web_config_catch')) ;
        if(empty($webConfig)){
            $configmodel = new \app\common\model\Config() ;
            $configmodel->setWebConfig() ;
            $this->web_config = Cache::get(config('web_config_catch')) ;
        }
        $this->setTitle() ;
    }

    /**
     * 设置标题
     */
    public function setTitle($title = '', $keywords = '', $description = ''){
        if($title == ""){
            $cid = $this->request->param('cid/d') ;
            $this->column_id = $cid ;
            if($this->column_id == 0){ //如果栏目ID为空
                $this->assign('title',$this->web_config['web_title']) ;
                $this->assign('keywords',$this->web_config['web_keywords']) ;
                $this->assign('description',$this->web_config['web_description']) ;
            }else{
                $controller_name = strtolower($this->request->controller()) ;
                switch ($controller_name){
                    case 'article' :
                        break ;
                    case 'single' :
                        break ;
                    case 'advert' :
                        break ;
                }
            }
        }else{
            $this->assign('title',$title) ;
            $this->assign('keywords',$keywords) ;
            $this->assign('description',$description) ;
        }
    }
}