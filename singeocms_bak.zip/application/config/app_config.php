<?php
return [
    //外部静态文件位置定义
    'plugins_static' => '/static/plugins/',
    //网站配置缓存key
    'web_config_catch' => 'web_config',
    //网站前端模板
    'web_tpl_path' => '../resource/default/',
] ;